package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Device
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Smart Home", appName)
  }

  @Test
  fun `verify device data model parameters`() {
    val light = Device(
      id = "light_living",
      name = "Ceiling Light",
      room = "Living Room",
      type = "LIGHT",
      isOn = true,
      brightness = 85
    )
    assertEquals("light_living", light.id)
    assertEquals("Ceiling Light", light.name)
    assertEquals("Living Room", light.room)
    assertEquals("LIGHT", light.type)
    assertEquals(true, light.isOn)
    assertEquals(85, light.brightness)
  }
}
