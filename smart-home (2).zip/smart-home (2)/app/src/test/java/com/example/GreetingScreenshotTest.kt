package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BackgroundGlow
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowButton
import com.example.ui.components.NeonSwitch
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent { 
      MyApplicationTheme { 
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          BackgroundGlow()
          
          GlassCard(
            modifier = Modifier.width(300.dp).padding(16.dp),
            isActive = true
          ) {
            Text("AI AUTONOMOUS COMFORT", fontSize = 11.sp, color = com.example.ui.theme.AccentGlow)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Living Room", fontSize = 22.sp, color = androidx.compose.ui.graphics.Color.White)
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("Ambient Ceiling Light", color = androidx.compose.ui.graphics.Color.White)
              val state = remember { mutableStateOf(true) }
              NeonSwitch(checked = state.value, onCheckedChange = { state.value = it })
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            GlowButton(
              text = "RUN WELCOME PRESET",
              onClick = {},
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      } 
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
