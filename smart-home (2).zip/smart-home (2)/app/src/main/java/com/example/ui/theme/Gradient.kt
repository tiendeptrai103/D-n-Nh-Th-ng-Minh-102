package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val MainGradient = Brush.linearGradient(
    colors = listOf(PrimaryGlow, SecondaryGlow)
)

val BackgroundGlowGradient = Brush.radialGradient(
    colors = listOf(PrimaryGlow.copy(alpha = 0.24f), Color.Transparent)
)

val CardSurfaceGradient = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.18f),
        Color.White.copy(alpha = 0.04f)
    )
)

val GlassHighlightGradient = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.18f),
        Color.White.copy(alpha = 0.02f)
    )
)
