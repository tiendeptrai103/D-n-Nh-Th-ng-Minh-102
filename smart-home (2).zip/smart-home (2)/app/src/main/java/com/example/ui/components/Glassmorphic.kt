
package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BackgroundGlow(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")

    val pulseAlpha1 by infiniteTransition.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha1"
    )

    val pulseAlpha2 by infiniteTransition.animateFloat(
        initialValue = 0.16f,
        targetValue = 0.38f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha2"
    )

    val driftX by infiniteTransition.animateFloat(
        initialValue = -0.06f,
        targetValue = 0.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "driftX"
    )

    val driftY by infiniteTransition.animateFloat(
        initialValue = -0.04f,
        targetValue = 0.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "driftY"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        drawRect(color = SpaceDarkBg, size = size)

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(PrimaryGlow.copy(alpha = pulseAlpha1), Color.Transparent),
                center = Offset(width * (0.84f + driftX * 0.1f), height * (0.14f + driftY * 0.08f)),
                radius = width * 0.75f
            ),
            radius = width * 0.75f,
            center = Offset(width * (0.84f + driftX * 0.1f), height * (0.14f + driftY * 0.08f))
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(SecondaryGlow.copy(alpha = pulseAlpha2), Color.Transparent),
                center = Offset(width * (0.16f - driftX * 0.08f), height * (0.56f + driftY * 0.05f)),
                radius = width * 0.85f
            ),
            radius = width * 0.85f,
            center = Offset(width * (0.16f - driftX * 0.08f), height * (0.56f + driftY * 0.05f))
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(AccentGlow.copy(alpha = 0.14f), Color.Transparent),
                center = Offset(width * (0.68f + driftX * 0.06f), height * (0.88f - driftY * 0.04f)),
                radius = width * 0.6f
            ),
            radius = width * 0.6f,
            center = Offset(width * (0.68f + driftX * 0.06f), height * (0.88f - driftY * 0.04f))
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(AccentGlow.copy(alpha = pulseAlpha2 * 0.45f), Color.Transparent),
                center = Offset(width * 0.45f, height * 0.33f),
                radius = width * 0.4f
            ),
            radius = width * 0.4f,
            center = Offset(width * 0.45f, height * 0.33f)
        )
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = AppCornerLarge,
    isActive: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (isActive) GlassCardGlowBorder else GlassCardBorder
    val shadowElevation = if (isActive) AppElevationActiveSurface else AppElevationSurface

    Box(
        modifier = modifier
            .shadow(
                elevation = shadowElevation,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = Color.Black.copy(alpha = 0.36f),
                spotColor = Color.Black.copy(alpha = 0.64f)
            )
            .graphicsLayer {
                clip = true
                shape = RoundedCornerShape(cornerRadius)
            }
            .background(CardSurfaceGradient)
            .drawBehind {
                drawRoundRect(
                    brush = GlassHighlightGradient,
                    size = size,
                    cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx())
                )
                if (isActive) {
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                AccentGlow.copy(alpha = 0.24f),
                                SecondaryGlow.copy(alpha = 0.12f)
                            )
                        ),
                        size = size,
                        cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx()),
                        alpha = 0.16f
                    )
                }
            }
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        borderColor.copy(alpha = 0.78f),
                        borderColor.copy(alpha = 0.18f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .padding(16.dp)
    ) {
        Column(content = content)
    }
}

@Composable
fun GlowButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = PrimaryGlow,
    testTagStr: String = "glow_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "scale"
    )

    Box(
        modifier = modifier
            .testTag(testTagStr)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(AppCornerButton))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .background(
                Brush.linearGradient(
                    colors = listOf(color, color.copy(alpha = 0.7f))
                )
            )
            .drawBehind {
                // Outer subtle glow reflection
                drawCircle(
                    color = color.copy(alpha = if (isPressed) 0.5f else 0.32f),
                    radius = size.width * (if (isPressed) 0.85f else 0.7f),
                    center = Offset(size.width / 2f, size.height / 2f)
                )

                // Top glossy highlight
                val glossHeight = size.height * 0.35f
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.08f),
                    topLeft = Offset(0f, 0f),
                    size = androidx.compose.ui.geometry.Size(size.width, glossHeight),
                    cornerRadius = CornerRadius(12f, 12f)
                )
            }
            .padding(vertical = 14.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun NeonSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    testTagStr: String = "neon_switch"
) {
    val transition = updateTransition(targetState = checked, label = "switch")
    val thumbOffset by transition.animateDp(
        transitionSpec = { spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium) },
        label = "thumb_pos"
    ) { isChecked ->
        if (isChecked) 24.dp else 2.dp
    }

    val glowAlpha by transition.animateFloat(
        transitionSpec = { tween(280) },
        label = "glow"
    ) { isChecked ->
        if (isChecked) 0.95f else 0.12f
    }

    val switchColor = if (checked) AccentGlow else Color.White.copy(alpha = 0.12f)

    // small pulsing when active
    val pulse = rememberInfiniteTransition(label = "switch_pulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(animation = tween(900, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .testTag(testTagStr)
            .width(52.dp)
            .height(30.dp)
            .clip(RoundedCornerShape(AppCornerPill))
            .clickable { onCheckedChange(!checked) }
            .background(Color.White.copy(alpha = 0.04f))
            .border(
                width = 1.dp,
                color = switchColor.copy(alpha = 0.45f),
                shape = RoundedCornerShape(AppCornerPill)
            )
            .padding(2.dp)
    ) {
        // glowing halo behind thumb when checked
        if (checked) {
            Box(
                modifier = Modifier
                    .offset(x = thumbOffset)
                    .size(28.dp)
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                    .drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(listOf(switchColor.copy(alpha = glowAlpha * 0.7f), Color.Transparent)),
                            radius = size.minDimension * 0.9f,
                            center = Offset(size.width / 2f, size.height / 2f)
                        )
                    }
            )
        }

        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color.White, switchColor)
                    )
                )
                .shadow(
                    elevation = if (checked) 10.dp else 0.dp,
                    shape = CircleShape,
                    ambientColor = switchColor.copy(alpha = 0.6f),
                    spotColor = switchColor.copy(alpha = 0.9f)
                )
        )
    }
}

@Composable
fun TemperatureDial(
    temperature: Float,
    onTemperatureChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var angle by remember { mutableStateOf(0f) }
    val minTemp = 16f
    val maxTemp = 30f

    // Convert temperature to circle angle (from -135 to +135 degrees)
    val tempRatio = (temperature - minTemp) / (maxTemp - minTemp)
    val targetAngle = -135f + tempRatio * 270f

    Box(
        modifier = modifier
            .size(240.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val touchPos = change.position
                    val angleRad = atan2(touchPos.y - center.y, touchPos.x - center.x)
                    var deg = (angleRad * 180 / PI).toFloat() + 90f
                    if (deg < 0) deg += 360f
                    
                    // Normalize to -135 to 135 deg dial
                    var dialDeg = deg - 180f
                    if (dialDeg < -180f) dialDeg += 360f
                    
                    if (dialDeg in -135f..135f) {
                        val ratio = (dialDeg + 135f) / 270f
                        val newTemp = minTemp + ratio * (maxTemp - minTemp)
                        onTemperatureChange(Math.round(newTemp * 2f) / 2f)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val outerRadius = size.minDimension / 2 * 0.9f
            val innerRadius = outerRadius * 0.8f

            // 1. Draw outer frosted track
            drawArc(
                color = Color.White.copy(alpha = 0.05f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = 16f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 8f))),
                size = Size(outerRadius * 2, outerRadius * 2),
                topLeft = Offset(center.x - outerRadius, center.y - outerRadius)
            )

            // 2. Draw active glow temperature track
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(PrimaryGlow, SecondaryGlow)
                ),
                startAngle = 135f,
                sweepAngle = tempRatio * 270f,
                useCenter = false,
                style = Stroke(width = 18f, cap = androidx.compose.ui.graphics.StrokeCap.Round),
                size = Size(outerRadius * 2, outerRadius * 2),
                topLeft = Offset(center.x - outerRadius, center.y - outerRadius)
            )

            // 3. Draw tick marks
            val tickCount = 20
            for (i in 0..tickCount) {
                val tickAngle = 135f + (i.toFloat() / tickCount) * 270f
                val rad = tickAngle * PI / 180.0
                val startX = center.x + (innerRadius * 0.9f).toFloat() * cos(rad).toFloat()
                val startY = center.y + (innerRadius * 0.9f).toFloat() * sin(rad).toFloat()
                val endX = center.x + innerRadius * cos(rad).toFloat()
                val endY = center.y + innerRadius * sin(rad).toFloat()

                val tickColor = if (tickAngle <= 135f + tempRatio * 270f) {
                    AccentGlow
                } else {
                    Color.White.copy(alpha = 0.15f)
                }

                drawLine(
                    color = tickColor,
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = 3f
                )
            }
        }

        // 4. Center Ring Container
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.05f),
                            Color.White.copy(alpha = 0.01f)
                        )
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${temperature}°C",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 32.sp
                )
                Text(
                    text = "COOLING",
                    color = AccentGlow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.5.sp
                )
            }
        }
    }
}

@Composable
fun PowerGraphCanvas(
    modifier: Modifier = Modifier,
    values: List<Float> = listOf(4.2f, 5.8f, 3.1f, 8.4f, 10.2f, 12.4f, 9.6f)
) {
    Canvas(modifier = modifier.fillMaxWidth().height(180.dp)) {
        val width = size.width
        val height = size.height
        val maxVal = values.maxOrNull() ?: 1.0f
        
        // Draw grid lines
        val gridCount = 4
        for (i in 0..gridCount) {
            val y = height - (i.toFloat() / gridCount) * height * 0.8f - 20f
            drawLine(
                color = Color.White.copy(alpha = 0.05f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 2f
            )
        }

        // Draw Bars
        val paddingBetween = 24f
        val itemWidth = (width - paddingBetween * (values.size + 1)) / values.size
        
        values.forEachIndexed { idx, value ->
            val barHeight = (value / maxVal) * height * 0.75f
            val x = paddingBetween + idx * (itemWidth + paddingBetween)
            val y = height - barHeight - 20f

            // Draw Bar Shadow Glow
            drawRoundRect(
                color = PrimaryGlow.copy(alpha = 0.15f),
                topLeft = Offset(x - 4f, y - 4f),
                size = Size(itemWidth + 8f, barHeight + 8f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )

            // Draw Actual Rounded Bar
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(AccentGlow, PrimaryGlow)
                ),
                topLeft = Offset(x, y),
                size = Size(itemWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
            )
        }
    }
}

@Composable
fun AudioVisualizerPulse(
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale1 by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse1"
    )
    val pulseScale2 by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 2.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse2"
    )

    Box(
        modifier = modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isActive) {
            // Pulse Ring 1
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = pulseScale2
                        scaleY = pulseScale2
                        alpha = (2.1f - pulseScale2) / 1.1f
                    }
                    .border(2.dp, SecondaryGlow.copy(alpha = 0.5f), CircleShape)
            )
            // Pulse Ring 2
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = pulseScale1
                        scaleY = pulseScale1
                        alpha = (1.6f - pulseScale1) / 0.6f
                    }
                    .border(2.dp, PrimaryGlow.copy(alpha = 0.6f), CircleShape)
            )
        }

        // Inner Solid Pulsing Core
        val coreScale by infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "core"
        )

        Box(
            modifier = Modifier
                .size(72.dp)
                .graphicsLayer {
                    scaleX = if (isActive) coreScale else 1.0f
                    scaleY = if (isActive) coreScale else 1.0f
                }
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(PrimaryGlow, SecondaryGlow)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color.White)
            )
        }
    }
}

@Composable
fun VideoStreamCanvas(
    modifier: Modifier = Modifier,
    motionDetected: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "video")
    
    val scanY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scan"
    )

    val blinkAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blink"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(AppCornerLarge))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(AppCornerLarge))
    ) {
        // CCTV Camera Render
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Deep background
            drawRect(Color(0xFF070B11))

            // Draw stylized CCTV static rooms lines
            drawLine(
                color = Color.White.copy(alpha = 0.1f),
                start = Offset(0f, height * 0.45f),
                end = Offset(width, height * 0.55f)
            )
            drawLine(
                color = Color.White.copy(alpha = 0.12f),
                start = Offset(width * 0.35f, 0f),
                end = Offset(width * 0.35f, height)
            )

            // Draw a simulated 3D doorway depth
            drawRect(
                color = Color.White.copy(alpha = 0.05f),
                topLeft = Offset(width * 0.1f, height * 0.2f),
                size = Size(width * 0.15f, height * 0.6f)
            )

            // Dynamic Scanning Line
            val sy = scanY * height
            drawLine(
                color = AccentGlow.copy(alpha = 0.4f),
                start = Offset(0f, sy),
                end = Offset(width, sy),
                strokeWidth = 3f
            )

            // Accent security scan glow trailing
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(AccentGlow.copy(alpha = 0.08f), Color.Transparent)
                ),
                topLeft = Offset(0f, sy - 30f),
                size = Size(width, 30f)
            )

            // Grid layout lines overlay
            val gridSpacing = 40f
            var gx = 0f
            while (gx < width) {
                drawLine(
                    color = Color.White.copy(alpha = 0.02f),
                    start = Offset(gx, 0f),
                    end = Offset(gx, height),
                    strokeWidth = 1f
                )
                gx += gridSpacing
            }
        }

        // Blink Status Dot
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (motionDetected) DangerGlow else AccentGlow.copy(alpha = blinkAlpha))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (motionDetected) "MOTION DETECTED" else "LIVE FEED",
                color = if (motionDetected) DangerGlow else Color.White.copy(alpha = 0.8f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        // Overlay camera stats
        Text(
            text = "CAM_FRONT_DOOR - 1080P",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 10.sp,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
        )

        // Hour stats
        Text(
            text = "UTC 2026-07-02",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 10.sp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp)
        )
    }
}
