package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.Device
import com.example.data.model.AutomationRule
import com.example.data.model.Scene
import com.example.data.model.HistoryLog
import com.example.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices")
    fun getAllDevicesFlow(): Flow<List<Device>>

    @Query("SELECT * FROM devices")
    suspend fun getAllDevices(): List<Device>

    @Query("SELECT * FROM devices WHERE id = :id")
    suspend fun getDeviceById(id: String): Device?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateDevice(device: Device)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllDevices(devices: List<Device>)

    @Update
    suspend fun updateDevice(device: Device)
}

@Dao
interface AutomationDao {
    @Query("SELECT * FROM automation_rules")
    fun getAllRulesFlow(): Flow<List<AutomationRule>>

    @Query("SELECT * FROM automation_rules WHERE isActive = 1")
    suspend fun getActiveRules(): List<AutomationRule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AutomationRule)

    @Update
    suspend fun updateRule(rule: AutomationRule)

    @Query("DELETE FROM automation_rules WHERE id = :id")
    suspend fun deleteRuleById(id: Int)
}

@Dao
interface SceneDao {
    @Query("SELECT * FROM scenes")
    fun getAllScenesFlow(): Flow<List<Scene>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllScenes(scenes: List<Scene>)

    @Update
    suspend fun updateScene(scene: Scene)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentHistoryLogsFlow(): Flow<List<HistoryLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: HistoryLog)

    @Query("DELETE FROM history_logs")
    suspend fun clearHistory()
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users LIMIT 1")
    fun getUserFlow(): Flow<User?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)
}

@Database(
    entities = [Device::class, AutomationRule::class, Scene::class, HistoryLog::class, User::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deviceDao(): DeviceDao
    abstract fun automationDao(): AutomationDao
    abstract fun sceneDao(): SceneDao
    abstract fun historyDao(): HistoryDao
    abstract fun userDao(): UserDao
}
