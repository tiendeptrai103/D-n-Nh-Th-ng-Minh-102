package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Device
import com.example.data.model.AutomationRule
import com.example.data.model.Scene
import com.example.data.model.HistoryLog
import com.example.ui.components.*
import com.example.ui.effects.BlurLayer
import com.example.ui.effects.NoiseOverlay
import com.example.ui.theme.*
import com.example.ui.viewmodel.ChatMessage
import com.example.ui.viewmodel.SmartHomeViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import java.text.SimpleDateFormat

@Composable
fun SmartHomeAppContent(viewModel: SmartHomeViewModel) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val activeDeviceDetail by viewModel.activeDeviceDetail.collectAsState()
    val isVoiceOpen by viewModel.isVoiceAssistantOpen.collectAsState()

    var currentScreen by remember { mutableStateOf("dashboard") }

    Box(modifier = Modifier.fillMaxSize()) {
        // Universal Premium Pulsing Background Glows
        BackgroundGlow()
        BlurLayer(modifier = Modifier.fillMaxSize(), alpha = 0.04f)
        NoiseOverlay(modifier = Modifier.fillMaxSize())

        if (!isLoggedIn) {
            LoginRegisterScreen(viewModel)
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header of screens
                Spacer(modifier = Modifier.height(12.dp))

                Box(modifier = Modifier.weight(1f)) {
                    when (currentScreen) {
                        "dashboard" -> DashboardScreen(viewModel, onNavigateToDetail = { dev -> viewModel.showDeviceDetails(dev) })
                        "scenes" -> ScenesScreen(viewModel)
                        "automation" -> AutomationScreen(viewModel)
                        "energy" -> EnergyScreen(viewModel)
                        "profile" -> ProfileScreen(viewModel)
                    }
                }

                // Custom Glass Bottom Navigation Bar
                BottomNavBar(
                    currentScreen = currentScreen,
                    onNavigate = { currentScreen = it },
                    onVoiceClick = { viewModel.openVoiceAssistant(true) }
                )
            }

            // High Fidelity Overlay: Device Control Screen
            AnimatedVisibility(
                visible = activeDeviceDetail != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                activeDeviceDetail?.let { device ->
                    DeviceControlScreen(
                        device = device,
                        viewModel = viewModel,
                        onClose = { viewModel.showDeviceDetails(null) }
                    )
                }
            }

            // High Fidelity Overlay: Voice Assistant / Chat overlay
            AnimatedVisibility(
                visible = isVoiceOpen,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
                modifier = Modifier.fillMaxSize()
            ) {
                VoiceAssistantDialog(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LoginRegisterScreen(viewModel: SmartHomeViewModel) {
    val email by viewModel.authEmail.collectAsState()
    val password by viewModel.authPassword.collectAsState()
    val name by viewModel.authName.collectAsState()
    val isRegister by viewModel.isRegisterMode.collectAsState()
    val error by viewModel.authError.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Large Glowing Logo
        Spacer(modifier = Modifier.height(40.dp))
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(PrimaryGlow.copy(alpha = 0.3f), Color.Transparent)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Home,
                contentDescription = "Logo",
                tint = AccentGlow,
                modifier = Modifier.size(54.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "SMART HOME",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 32.sp,
            letterSpacing = 2.sp
        )
        Text(
            text = "Premium Autonomous Comfort",
            color = SlateTextMuted,
            fontSize = 14.sp,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(40.dp))

        // Glassmorphism login container
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            isActive = true
        ) {
            Text(
                text = if (isRegister) "Create Account" else "Welcome back",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (isRegister) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { viewModel.setAuthName(it) },
                    label = { Text("Your Name", color = SlateTextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentGlow,
                        unfocusedBorderColor = GlassCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("name_input")
                        .padding(bottom = 12.dp)
                )
            }

            OutlinedTextField(
                value = email,
                onValueChange = { viewModel.setAuthEmail(it) },
                label = { Text("Email Address", color = SlateTextMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = AccentGlow,
                    unfocusedBorderColor = GlassCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("email_input")
                    .padding(bottom = 12.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = { viewModel.setAuthPassword(it) },
                label = { Text("Password", color = SlateTextMuted) },
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = AccentGlow,
                    unfocusedBorderColor = GlassCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("password_input")
                    .padding(bottom = 12.dp)
            )

            error?.let {
                Text(
                    text = it,
                    color = DangerGlow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            // Glowing Submit Button
            GlowButton(
                text = if (isRegister) "REGISTER NOW" else "SIGN IN SECURELY",
                onClick = { if (isRegister) viewModel.performRegister() else viewModel.performLogin() },
                color = if (isRegister) SecondaryGlow else PrimaryGlow,
                modifier = Modifier.fillMaxWidth(),
                testTagStr = "submit_auth_button"
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Option details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isRegister) "Already registered?" else "New to Smart Home?",
                    color = SlateTextMuted,
                    fontSize = 13.sp
                )
                Text(
                    text = if (isRegister) "Login" else "Register",
                    color = AccentGlow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clickable { viewModel.setRegisterMode(!isRegister) }
                        .testTag("switch_auth_mode")
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Social Single Sign On Demo
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HorizontalDivider(modifier = Modifier.weight(1f), color = GlassCardBorder)
            Text(" SOCIAL SIGN IN ", color = SlateTextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp))
            HorizontalDivider(modifier = Modifier.weight(1f), color = GlassCardBorder)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Simulated Google Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(AppCornerMedium))
                .background(Color.White.copy(alpha = 0.05f))
                .border(1.dp, GlassCardBorder, RoundedCornerShape(AppCornerMedium))
                .clickable { viewModel.performLogin() }
                .padding(14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Star, contentDescription = "Google", tint = AccentGlow, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("CONTINUE WITH GOOGLE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
fun DashboardScreen(
    viewModel: SmartHomeViewModel,
    onNavigateToDetail: (Device) -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val devicesState by viewModel.devices.collectAsState()
    val roomSelected by viewModel.currentRoom.collectAsState()

    val rooms = listOf("All", "Living Room", "Bedroom", "Front Door")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. App bar / Welcome Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Good Morning,",
                        color = SlateTextMuted,
                        fontSize = 14.sp
                    )
                    Text(
                        text = userState?.name ?: "Robbie",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 28.sp,
                        letterSpacing = 1.sp
                    )
                }

                // Avatar and alert badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.openVoiceAssistant(true) },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.05f))
                    ) {
                        Box {
                            Icon(Icons.Default.Notifications, contentDescription = "Alerts", tint = Color.White)
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(DangerGlow)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(PrimaryGlow, SecondaryGlow)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("R", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }
                }
            }
        }

        // 2. Geofence GPS Simulation Alert
        item {
            userState?.let { usr ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    isActive = usr.isAway
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (usr.isAway) "Away Mode - Geofencing Active" else "User is At Home",
                                color = if (usr.isAway) WarningGlow else AccentGlow,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (usr.isAway) "Simulated Distance: ${String.format("%.1f", usr.distanceKm)} km" else "All rules executing in Local Mode.",
                                color = SlateTextLight,
                                fontSize = 12.sp
                            )
                        }
                        GlowButton(
                            text = if (usr.isAway) "ARRIVE HOME" else "DEPART HOME",
                            onClick = { viewModel.toggleGpsSimulation() },
                            color = if (usr.isAway) AccentGlow else SecondaryGlow,
                            testTagStr = "gps_simulate_button"
                        )
                    }
                }
            }
        }

        // 3. Room Filters Pills
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(rooms) { room ->
                    val isSelected = roomSelected == room
                    val pillBg = if (isSelected) PrimaryGlow else Color.White.copy(alpha = 0.05f)
                    val pillBorder = if (isSelected) GlassCardGlowBorder else GlassCardBorder

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(AppCornerPill))
                            .background(pillBg)
                            .border(1.dp, pillBorder, RoundedCornerShape(100.dp))
                            .clickable { viewModel.selectRoom(room) }
                            .padding(vertical = 10.dp, horizontal = 18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = room,
                            color = if (isSelected) Color.White else SlateTextLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 4. Device Grid
        item {
            val filteredDevices = if (roomSelected == "All") {
                devicesState
            } else {
                devicesState.filter { it.room == roomSelected }
            }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Manually partition in 2-column list due to LazyColumn grid inside restriction
                val rows = filteredDevices.chunked(2)
                for (row in rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (dev in row) {
                            val isDevOn = when (dev.type) {
                                "LOCK" -> !dev.isLocked
                                "CAMERA" -> dev.isRecording
                                else -> dev.isOn
                            }

                            val interactionSource = remember { MutableInteractionSource() }
                            val isPressed by interactionSource.collectIsPressedAsState()
                            val cardScale by animateFloatAsState(
                                targetValue = if (isPressed) 0.97f else 1f,
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessMedium
                                ),
                                label = "device_card_scale"
                            )
                            val iconColor by animateColorAsState(
                                targetValue = if (isDevOn) AccentGlow else SlateTextMuted,
                                label = "device_icon_color"
                            )
                            val statusColor by animateColorAsState(
                                targetValue = if (dev.motionDetected) DangerGlow else if (isDevOn) AccentGlow else SlateTextMuted,
                                label = "device_status_color"
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .graphicsLayer {
                                        scaleX = cardScale
                                        scaleY = cardScale
                                    }
                                    .clip(RoundedCornerShape(AppCornerLarge))
                                    .clickable(
                                        interactionSource = interactionSource,
                                        indication = null,
                                        onClick = { onNavigateToDetail(dev) }
                                    )
                            ) {
                                GlassCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    isActive = isDevOn
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .drawBehind {
                                                    if (isDevOn) {
                                                        // soft radial glow behind icon
                                                        drawCircle(
                                                            brush = Brush.radialGradient(
                                                                colors = listOf(iconColor.copy(alpha = 0.28f), Color.Transparent)
                                                            ),
                                                            radius = size.minDimension * 0.9f,
                                                            center = Offset(size.width / 2f, size.height / 2f)
                                                        )
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = getIconForType(dev.type),
                                                contentDescription = null,
                                                tint = iconColor,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }

                                        NeonSwitch(
                                            checked = isDevOn,
                                            onCheckedChange = { viewModel.toggleDevice(dev) },
                                            testTagStr = "switch_${dev.id}"
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = dev.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = dev.room,
                                        color = SlateTextMuted,
                                        fontSize = 11.sp
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = when (dev.type) {
                                            "LIGHT" -> if (dev.isOn) "ON (${dev.brightness}%)" else "OFF"
                                            "AC" -> if (dev.isOn) "COOLING (${dev.temperature}°C)" else "STANDBY"
                                            "FAN" -> if (dev.isOn) "RUNNING (${dev.fanSpeed})" else "STOPPED"
                                            "LOCK" -> if (dev.isLocked) "SECURED" else "UNLOCKED"
                                            "CAMERA" -> if (dev.motionDetected) "MOTION ALERT!" else "MONITORING"
                                            "PLUG" -> if (dev.isOn) "ACTIVE (${String.format("%.1f", dev.powerUsageW)}W)" else "STANDBY"
                                            else -> "OFF"
                                        },
                                        color = statusColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                        if (row.size < 2) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // 5. Mini Energy consumption widget
        item {
            val liveDraw = devicesState.sumOf { it.powerUsageW.toDouble() }.toFloat()
            val totalUsage = devicesState.sumOf { it.totalUsageKwh.toDouble() }.toFloat()

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("POWER USAGE TODAY", color = SlateTextMuted, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                        Text("${String.format("%.1f", totalUsage)} kWh", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
                        Text("Active Draw: ${String.format("%.1f", liveDraw)} Watts", color = AccentGlow, fontSize = 12.sp)
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.05f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Star, contentDescription = "Analytics", tint = PrimaryGlow)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                PowerGraphCanvas(modifier = Modifier.height(60.dp))
            }
        }
        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun DeviceControlScreen(
    device: Device,
    viewModel: SmartHomeViewModel,
    onClose: () -> Unit
) {
    var brightVal by remember(device.brightness) { mutableStateOf(device.brightness.toFloat()) }
    var tempVal by remember(device.temperature) { mutableStateOf(device.temperature) }
    var fanSp by remember(device.fanSpeed) { mutableStateOf(device.fanSpeed) }

    val isDevActive = when (device.type) {
        "LOCK" -> !device.isLocked
        "CAMERA" -> device.isRecording
        else -> device.isOn
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceDarkBg)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose, modifier = Modifier.testTag("back_button")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("DEVICE CONTROL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Box(modifier = Modifier.width(48.dp)) // Spacer placeholder
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Device summary
        Text(text = device.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
        Text(text = "${device.room} • autonomous IoT", color = SlateTextMuted, fontSize = 13.sp)

        Spacer(modifier = Modifier.height(24.dp))

        // Large Graphical Controller based on Type
        when (device.type) {
            "LIGHT" -> {
                // Light bulb graphic drawing with color glow
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .drawBehind {
                                if (device.isOn) {
                                    drawCircle(
                                        color = Color(android.graphics.Color.parseColor(device.rgbColor))
                                            .copy(alpha = 0.35f * (brightVal / 100f)),
                                        radius = size.width * 0.6f,
                                        center = Offset(size.width / 2f, size.height / 2f)
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "Bulb",
                            tint = if (device.isOn) Color(android.graphics.Color.parseColor(device.rgbColor)) else SlateTextMuted,
                            modifier = Modifier.size(80.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Brightness slider
                    Text("BRIGHTNESS: ${brightVal.toInt()}%", color = Color.White, fontWeight = FontWeight.Bold)
                    Slider(
                        value = brightVal,
                        onValueChange = {
                            brightVal = it
                            viewModel.adjustDevice(device.copy(brightness = it.toInt()))
                        },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = PrimaryGlow,
                            activeTrackColor = AccentGlow
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("brightness_slider")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Color dots selection
                    Text("ATMOSPHERE PROFILE", color = SlateTextMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    val colors = listOf("#4DA6FF", "#7B61FF", "#00FFD1", "#FF5A5A", "#FFA13D")
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        colors.forEach { hex ->
                            val parsed = Color(android.graphics.Color.parseColor(hex))
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(parsed)
                                    .border(
                                        width = if (device.rgbColor == hex) 3.dp else 0.dp,
                                        color = Color.White,
                                        shape = CircleShape
                                    )
                                    .clickable { viewModel.adjustDevice(device.copy(rgbColor = hex)) }
                            )
                        }
                    }
                }
            }
            "AC" -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TemperatureDial(
                        temperature = tempVal,
                        onTemperatureChange = {
                            tempVal = it
                            viewModel.adjustDevice(device.copy(temperature = it))
                        }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Modes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val modes = listOf("COOL", "WARM", "DRY", "AUTO")
                        modes.forEach { mode ->
                            val isSelected = device.acMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(AppCornerSmall))
                                    .background(if (isSelected) SecondaryGlow else Color.White.copy(alpha = 0.05f))
                                    .border(1.dp, if (isSelected) GlassCardGlowBorder else GlassCardBorder, RoundedCornerShape(AppCornerSmall))
                                    .clickable { viewModel.adjustDevice(device.copy(acMode = mode)) }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(mode, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            "CAMERA" -> {
                Column(modifier = Modifier.fillMaxWidth()) {
                    VideoStreamCanvas(motionDetected = device.motionDetected)

                    Spacer(modifier = Modifier.height(24.dp))

                    // Camera tools
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButtonAction(icon = Icons.Default.PlayArrow, label = "Record", active = device.isRecording) {
                            viewModel.toggleDevice(device)
                        }
                        IconButtonAction(icon = Icons.Default.Share, label = "Snapshot", active = false) {}
                        IconButtonAction(icon = Icons.Default.Warning, label = "Siren Alert", active = device.motionDetected) {
                            // Mock manual siren
                        }
                    }
                }
            }
            "LOCK" -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .clip(CircleShape)
                            .background(if (device.isLocked) DangerGlow.copy(alpha = 0.15f) else AccentGlow.copy(alpha = 0.15f))
                            .border(2.dp, if (device.isLocked) DangerGlow else AccentGlow, CircleShape)
                            .clickable { viewModel.toggleDevice(device) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (device.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Lock",
                            tint = if (device.isLocked) DangerGlow else AccentGlow,
                            modifier = Modifier.size(64.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = if (device.isLocked) "FRONT DOOR IS SECURED" else "FRONT DOOR IS UNLOCKED",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                    Text(
                        text = if (device.isLocked) "Long press lock button or tap to unlock." else "Tap to secure your household.",
                        color = SlateTextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
            "FAN" -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val rotation by rememberInfiniteTransition(label = "").animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(if (device.isOn) 1200 else 0, easing = LinearEasing)
                        ),
                        label = ""
                    )

                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .graphicsLayer { rotationZ = rotation },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Blade",
                            tint = if (device.isOn) AccentGlow else SlateTextMuted,
                            modifier = Modifier.size(90.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text("FAN SPEED PROFILE", color = SlateTextMuted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val speeds = listOf("LOW", "MED", "HIGH", "AUTO")
                        speeds.forEach { speed ->
                            val isSelected = device.fanSpeed == speed
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(AppCornerSmall))
                                    .background(if (isSelected) PrimaryGlow else Color.White.copy(alpha = 0.05f))
                                    .border(1.dp, if (isSelected) GlassCardGlowBorder else GlassCardBorder, RoundedCornerShape(AppCornerSmall))
                                    .clickable { viewModel.adjustDevice(device.copy(fanSpeed = speed, isOn = true)) }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(speed, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            "PLUG" -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Plug",
                        tint = if (device.isOn) AccentGlow else SlateTextMuted,
                        modifier = Modifier.size(90.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (device.isOn) "APPLIANCE PLUG IS LIVE" else "APPLIANCE PLUG DISARMED",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    PowerGraphCanvas()
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Big ON/OFF Slider Pill at bottom
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("HARDWARE POWER STATE", color = SlateTextMuted, fontSize = 11.sp)
                    Text(if (isDevActive) "ONLINE & BROADCASTING" else "POWER CUT - SAVING ENERGY", color = if (isDevActive) AccentGlow else WarningGlow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                NeonSwitch(
                    checked = isDevActive,
                    onCheckedChange = { viewModel.toggleDevice(device) },
                    testTagStr = "hardware_detail_switch"
                )
            }
        }
    }
}

@Composable
fun IconButtonAction(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(AppCornerMedium))
            .background(if (active) SecondaryGlow else Color.White.copy(alpha = 0.05f))
            .border(1.dp, if (active) GlassCardGlowBorder else GlassCardBorder, RoundedCornerShape(AppCornerMedium))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = icon, contentDescription = label, tint = if (active) Color.White else SlateTextLight, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, color = SlateTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ScenesScreen(viewModel: SmartHomeViewModel) {
    val scenes by viewModel.scenes.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("SCENE MANAGEMENT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text("Automate multiple devices into comfort presets simultaneously.", color = SlateTextMuted, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(12.dp))
        }

        items(scenes) { scene ->
            val interactionSource = remember { MutableInteractionSource() }
            val isPressed by interactionSource.collectIsPressedAsState()
            val cardScale by animateFloatAsState(
                targetValue = if (isPressed) 0.985f else 1f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                label = "scene_card_scale"
            )

            Box(modifier = Modifier.graphicsLayer { scaleX = cardScale; scaleY = cardScale }) {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(interactionSource = interactionSource, indication = null) { viewModel.activateScene(scene.id) },
                    isActive = false
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .drawBehind {
                                        drawCircle(
                                            brush = Brush.radialGradient(listOf(SecondaryGlow.copy(alpha = 0.18f), Color.Transparent)),
                                            radius = size.minDimension * 0.9f,
                                            center = Offset(size.width / 2f, size.height / 2f)
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = getSceneIcon(scene.id),
                                    contentDescription = null,
                                    tint = SecondaryGlow,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column {
                                Text(scene.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(scene.description, color = SlateTextMuted, fontSize = 12.sp)
                            }
                        }

                        GlowButton(
                            text = "RUN",
                            onClick = { viewModel.activateScene(scene.id) },
                            color = PrimaryGlow,
                            modifier = Modifier
                                .clip(RoundedCornerShape(AppCornerTiny))
                                .height(36.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AutomationScreen(viewModel: SmartHomeViewModel) {
    val rules by viewModel.rules.collectAsState()
    val devices by viewModel.devices.collectAsState()

    var showCreator by remember { mutableStateOf(false) }

    // Creator State Parameters
    var ruleName by remember { mutableStateOf("") }
    var triggerType by remember { mutableStateOf("TIME") }
    var conditionVal by remember { mutableStateOf("") }
    var targetDeviceId by remember { mutableStateOf("") }
    var actionType by remember { mutableStateOf("TURN_ON") }
    var actionValue by remember { mutableStateOf("") }

    if (showCreator) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SpaceDarkBg)
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("NEW AUTOMATION", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
                IconButton(onClick = { showCreator = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = ruleName,
                    onValueChange = { ruleName = it },
                    label = { Text("Rule Title", color = SlateTextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rule_title_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Trigger Conditions Choose
                Text("TRIGGER ELEMENT (IF)", color = SlateTextMuted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val triggers = listOf("TIME", "MOTION", "TEMP", "LOCATION")
                    triggers.forEach { trig ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(AppCornerTiny))
                                .background(if (triggerType == trig) PrimaryGlow else Color.White.copy(alpha = 0.05f))
                                .clickable { triggerType = trig }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(trig, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = conditionVal,
                    onValueChange = { conditionVal = it },
                    label = { Text("Trigger Criteria (e.g. 18:00 or 30.0)", color = SlateTextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("condition_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Target select
                Text("TARGET DEVICE (THEN)", color = SlateTextMuted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(devices) { dev ->
                        val isSelected = targetDeviceId == dev.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) SecondaryGlow else Color.White.copy(alpha = 0.05f))
                                .clickable { targetDeviceId = dev.id }
                                .padding(vertical = 8.dp, horizontal = 12.dp)
                        ) {
                            Text(dev.name, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("HARDWARE ACTION", color = SlateTextMuted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val actions = listOf("TURN_ON", "TURN_OFF", "SET_TEMP", "LOCK", "UNLOCK")
                    actions.forEach { act ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(AppCornerTiny))
                                .background(if (actionType == act) AccentGlow else Color.White.copy(alpha = 0.05f))
                                .clickable { actionType = act }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(act, color = if (actionType == act) DarkNavyText else Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = actionValue,
                    onValueChange = { actionValue = it },
                    label = { Text("Action Value (e.g. 24.0 or leave blank)", color = SlateTextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("action_val_input")
                )

                Spacer(modifier = Modifier.height(20.dp))

                GlowButton(
                    text = "SAVE AUTOMATION RULE",
                    onClick = {
                        if (ruleName.isNotEmpty() && targetDeviceId.isNotEmpty()) {
                            viewModel.createAutomationRule(ruleName, triggerType, conditionVal, targetDeviceId, actionType, actionValue)
                            showCreator = false
                            ruleName = ""
                            conditionVal = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTagStr = "save_rule_button"
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .windowInsetsPadding(WindowInsets.safeDrawing),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AUTOMATION MATRIX", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
                        Text("Autonomous rule engines evaluating locally.", color = SlateTextMuted, fontSize = 13.sp)
                    }

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(PrimaryGlow)
                            .clickable { showCreator = true }
                            .testTag("add_rule_fab"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            items(rules) { rule ->
                val associatedDevice = devices.find { it.id == rule.actionDeviceId }
                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val scale by animateFloatAsState(if (isPressed) 0.985f else 1f, animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy))

                Box(modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(interactionSource = interactionSource, indication = null) { viewModel.toggleRule(rule) },
                        isActive = rule.isActive
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rule.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(
                                    text = "IF [${rule.triggerType}] is \"${rule.triggerCondition}\"",
                                    color = AccentGlow,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "THEN ${rule.actionType} on device [${associatedDevice?.name ?: "Unknown"}]",
                                    color = SlateTextMuted,
                                    fontSize = 12.sp
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                NeonSwitch(
                                    checked = rule.isActive,
                                    onCheckedChange = { viewModel.toggleRule(rule) },
                                    testTagStr = "switch_rule_${rule.id}"
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                IconButton(onClick = { viewModel.deleteRule(rule.id) }) {
                                    Box(modifier = Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerGlow, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EnergyScreen(viewModel: SmartHomeViewModel) {
    val devices by viewModel.devices.collectAsState()
    val totalKwh = devices.sumOf { it.totalUsageKwh.toDouble() }.toFloat()
    val totalWatts = devices.sumOf { it.powerUsageW.toDouble() }.toFloat()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("ENERGY METRICS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text("Detailed autonomous power tracking charts.", color = SlateTextMuted, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(12.dp))
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), isActive = true) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("POWER DEMAND", color = SlateTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${String.format("%.1f", totalWatts)} W", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
                        Text("Live Drawing Rate", color = AccentGlow, fontSize = 11.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TODAY'S TOTAL", color = SlateTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${String.format("%.1f", totalKwh)} kWh", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
                        Text("Accumulated Energy", color = SecondaryGlow, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("HISTORICAL INTENSITY CHART", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Aggregated hourly metrics (kWh)", color = SlateTextMuted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))

                PowerGraphCanvas()
            }
        }

        item {
            Text("DEVICE CONSUMPTION BREAKDOWN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        items(devices) { dev ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(36.dp).drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(listOf(AccentGlow.copy(alpha = 0.18f), Color.Transparent)),
                                radius = size.minDimension * 0.9f,
                                center = Offset(size.width / 2f, size.height / 2f)
                            )
                        }, contentAlignment = Alignment.Center) {
                            Icon(imageVector = getIconForType(dev.type), contentDescription = null, tint = AccentGlow, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(dev.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(dev.room, color = SlateTextMuted, fontSize = 11.sp)
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("${String.format("%.1f", dev.powerUsageW)} W", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${String.format("%.2f", dev.totalUsageKwh)} kWh Total", color = SlateTextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(viewModel: SmartHomeViewModel) {
    val userState by viewModel.user.collectAsState()
    val historyLogs by viewModel.history.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("USER PROFILE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text("Manage secure connections and historic auditing.", color = SlateTextMuted, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(12.dp))
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), isActive = true) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(colors = listOf(PrimaryGlow, SecondaryGlow))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("R", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(userState?.name ?: "Robbie", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(userState?.email ?: "laxin.27112000@gmail.com", color = SlateTextMuted, fontSize = 13.sp)
                        Text("Superuser Authorization Level", color = AccentGlow, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.weight(1f))
                    GlowButton(text = "LOG OUT", onClick = { viewModel.performLogout() }, color = DangerGlow, modifier = Modifier.height(40.dp).width(120.dp))
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("HISTORIC AUDITING LOGS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    text = "CLEAR LOGS",
                    color = DangerGlow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.clickable { viewModel.clearLogHistory() }
                )
            }
        }

        items(historyLogs) { log ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(getLogTypeColor(log.type))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(log.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text(log.message, color = SlateTextLight, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    Text(
                        text = SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(log.timestamp)),
                        color = SlateTextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }

        item {
            GlowButton(
                text = "DISCONNECT & LOG OUT",
                onClick = { viewModel.performLogout() },
                color = DangerGlow,
                modifier = Modifier.fillMaxWidth(),
                testTagStr = "logout_button"
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun VoiceAssistantDialog(viewModel: SmartHomeViewModel) {
    val messages by viewModel.chatMessages.collectAsState()
    val isListening by viewModel.isVoiceListening.collectAsState()

    var textInput by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceDarkBg.copy(alpha = 0.95f))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // Header close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isListening) AccentGlow else SlateTextMuted)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("AI ASSISTANT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                }

                IconButton(onClick = { viewModel.openVoiceAssistant(false) }, modifier = Modifier.testTag("close_voice_button")) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Chat Messages Box
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.03f))
                    .border(1.dp, GlassCardBorder, RoundedCornerShape(AppCornerButton))
                    .padding(12.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    reverseLayout = true,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Reverse list for bottom feeding messages
                    items(messages.reversed()) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (msg.isUser) SecondaryGlow else Color.White.copy(alpha = 0.07f))
                                    .border(1.dp, if (msg.isUser) GlassCardGlowBorder else GlassCardBorder, RoundedCornerShape(16.dp))
                                    .padding(12.dp)
                            ) {
                                Text(msg.text, color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Pulse audio visualizer inside voice overlay
            if (isListening) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AudioVisualizerPulse(isActive = true)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Listening for commands...", color = AccentGlow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Suggestion voice commands
                    Text("TRY SPEAKING SELECTION:", color = SlateTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlowButton(text = "Bật Đèn", onClick = { viewModel.triggerSimulatedVoicePhrase("Bật đèn phòng khách") }, color = PrimaryGlow)
                        GlowButton(text = "Tắt Đèn", onClick = { viewModel.triggerSimulatedVoicePhrase("Tắt đèn phòng khách") }, color = SecondaryGlow)
                        GlowButton(text = "Khóa Cửa", onClick = { viewModel.triggerSimulatedVoicePhrase("Khóa cửa chính") }, color = DangerGlow)
                    }
                }
            } else {
                // Keyboard Input Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("Ask Robbie to adjust devices...", color = SlateTextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentGlow,
                            unfocusedBorderColor = GlassCardBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_text_input")
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    IconButton(
                        onClick = {
                            viewModel.sendChatMessage(textInput)
                            textInput = ""
                        },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(PrimaryGlow)
                            .testTag("send_chat_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavBar(
    currentScreen: String,
    onNavigate: (String) -> Unit,
    onVoiceClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(16.dp)
            .height(76.dp)
            .clip(RoundedCornerShape(AppCornerNav))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.14f),
                        Color.White.copy(alpha = 0.08f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(GlassCardBorder.copy(alpha = 0.8f), GlassCardBorder.copy(alpha = 0.2f))
                ),
                shape = RoundedCornerShape(AppCornerNav)
            )
            .shadow(
                elevation = AppElevationActiveSurface,
                shape = RoundedCornerShape(AppCornerNav),
                ambientColor = Color.Black.copy(alpha = 0.35f),
                spotColor = Color.Black.copy(alpha = 0.5f)
            )
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButtonNav(icon = Icons.Default.Home, label = "Home", active = currentScreen == "dashboard") { onNavigate("dashboard") }
            IconButtonNav(icon = Icons.Default.PlayArrow, label = "Scenes", active = currentScreen == "scenes") { onNavigate("scenes") }

            val voiceInteractionSource = remember { MutableInteractionSource() }
            val voicePressed by voiceInteractionSource.collectIsPressedAsState()
            val voiceScale by animateFloatAsState(
                targetValue = if (voicePressed) 0.92f else 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                ),
                label = "voice_button_scale"
            )

            Box(
                modifier = Modifier
                    .size(58.dp)
                    .graphicsLayer {
                        scaleX = voiceScale
                        scaleY = voiceScale
                    }
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(PrimaryGlow, SecondaryGlow)
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    .shadow(12.dp, CircleShape, ambientColor = AccentGlow.copy(alpha = 0.25f), spotColor = PrimaryGlow)
                    .clickable(
                        interactionSource = voiceInteractionSource,
                        indication = null,
                        onClick = onVoiceClick
                    )
                    .testTag("bottom_voice_fab"),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Voice", tint = Color.White, modifier = Modifier.size(28.dp))
            }

            IconButtonNav(icon = Icons.Default.Add, label = "Auto", active = currentScreen == "automation") { onNavigate("automation") }
            IconButtonNav(icon = Icons.Default.Person, label = "Profile", active = currentScreen == "profile") { onNavigate("profile") }
        }
    }
}

@Composable
fun IconButtonNav(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val iconScale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "nav_icon_scale"
    )
    val iconTint by animateColorAsState(
        targetValue = if (active) AccentGlow else SlateTextMuted,
        label = "nav_icon_tint"
    )

    IconButton(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = Modifier
            .testTag("nav_${label.lowercase()}")
            .graphicsLayer {
                scaleX = iconScale
                scaleY = iconScale
            }
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconTint,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(label, color = iconTint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// Helpers
fun getIconForType(type: String): ImageVector {
    return when (type) {
        "LIGHT" -> Icons.Default.Lightbulb
        "AC" -> Icons.Default.Air
        "FAN" -> Icons.Default.Refresh
        "LOCK" -> Icons.Default.Lock
        "CAMERA" -> Icons.Default.Videocam
        "PLUG" -> Icons.Default.Power
        else -> Icons.Default.Settings
    }
}

fun getSceneIcon(id: String): ImageVector {
    return when (id) {
        "good_night" -> Icons.Default.Bedtime
        "welcome_home" -> Icons.Default.Home
        "movie_time" -> Icons.Default.Movie
        "away_mode" -> Icons.AutoMirrored.Filled.ExitToApp
        else -> Icons.Default.Star
    }
}

fun getLogTypeColor(type: String): Color {
    return when (type) {
        "SECURITY" -> DangerGlow
        "MOTION" -> WarningGlow
        "LOCK" -> AccentGlow
        "POWER" -> PrimaryGlow
        else -> SecondaryGlow
    }
}
