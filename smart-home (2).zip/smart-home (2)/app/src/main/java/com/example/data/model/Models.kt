package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "devices")
data class Device(
    @PrimaryKey val id: String,
    val name: String,
    val room: String,
    val type: String, // LIGHT, AC, FAN, LOCK, CAMERA, PLUG
    val isOn: Boolean = false,
    val brightness: Int = 100, // 0 - 100
    val rgbColor: String = "#4DA6FF", // Hex color representation
    val temperature: Float = 24.0f, // 16.0 - 30.0
    val acMode: String = "COOL", // COOL, WARM, AUTO, DRY
    val fanSpeed: String = "AUTO", // LOW, MED, HIGH, AUTO
    val isLocked: Boolean = true,
    val isRotating: Boolean = false,
    val powerUsageW: Float = 0.0f, // Current active power draw in Watts
    val totalUsageKwh: Float = 12.4f, // Accumulated energy
    val isRecording: Boolean = false,
    val motionDetected: Boolean = false
)

@Entity(tableName = "automation_rules")
data class AutomationRule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val triggerType: String, // TIME, MOTION, TEMP, LIGHT, LOCATION
    val triggerCondition: String, // Value or criteria (e.g. "18:00", "MOTION_DETECTED", "TEMP > 30", "GPS_NEAR")
    val actionDeviceId: String,
    val actionType: String, // TURN_ON, TURN_OFF, SET_TEMP, SET_BRIGHTNESS, LOCK, UNLOCK
    val actionValue: String = "",
    val isActive: Boolean = true
)

@Entity(tableName = "scenes")
data class Scene(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val iconName: String,
    val isActive: Boolean = false
)

@Entity(tableName = "history_logs")
data class HistoryLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String // SECURITY, MOTION, SYSTEM, LOCK, POWER
)

@Entity(tableName = "users")
data class User(
    @PrimaryKey val email: String,
    val name: String,
    val homeLocationLat: Double = 21.0285, // Default Hanoi
    val homeLocationLng: Double = 105.8542,
    val isAway: Boolean = false,
    val distanceKm: Double = 0.0
)
