package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.model.Device
import com.example.data.model.AutomationRule
import com.example.data.model.Scene
import com.example.data.model.HistoryLog
import com.example.data.model.User
import com.example.data.repository.SmartHomeRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val text: String, val isUser: Boolean)

class SmartHomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SmartHomeRepository(application)

    // DB flows bridged as StateFlows for compose
    val devices: StateFlow<List<Device>> = repository.devicesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rules: StateFlow<List<AutomationRule>> = repository.rulesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scenes: StateFlow<List<Scene>> = repository.scenesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<HistoryLog>> = repository.historyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val user: StateFlow<User?> = repository.userFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // UI Interactive States
    private val _currentRoom = MutableStateFlow("All")
    val currentRoom: StateFlow<String> = _currentRoom

    private val _activeDeviceDetail = MutableStateFlow<Device?>(null)
    val activeDeviceDetail: StateFlow<Device?> = _activeDeviceDetail

    // Chat AI States
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("Hi! I'm your Smart Home AI Assistant. How can I help control your home today?", false)
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    private val _isVoiceAssistantOpen = MutableStateFlow(false)
    val isVoiceAssistantOpen: StateFlow<Boolean> = _isVoiceAssistantOpen

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening

    // Auth Simulation States
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    private val _authEmail = MutableStateFlow("laxin.27112000@gmail.com")
    val authEmail: StateFlow<String> = _authEmail

    private val _authPassword = MutableStateFlow("123456")
    val authPassword: StateFlow<String> = _authPassword

    private val _authName = MutableStateFlow("Robbie")
    val authName: StateFlow<String> = _authName

    private val _isRegisterMode = MutableStateFlow(false)
    val isRegisterMode: StateFlow<Boolean> = _isRegisterMode

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError

    fun selectRoom(room: String) {
        _currentRoom.value = room
    }

    fun showDeviceDetails(device: Device?) {
        _activeDeviceDetail.value = device
    }

    // Toggle device state manually
    fun toggleDevice(device: Device) {
        viewModelScope.launch {
            val updated = when (device.type) {
                "LOCK" -> device.copy(isLocked = !device.isLocked)
                "CAMERA" -> device.copy(isRecording = !device.isRecording)
                else -> device.copy(isOn = !device.isOn)
            }
            repository.updateDevice(updated)
            
            // Sync current details card if active
            if (_activeDeviceDetail.value?.id == device.id) {
                _activeDeviceDetail.value = updated
            }

            val statusStr = when (device.type) {
                "LOCK" -> if (updated.isLocked) "SECURED" else "UNLOCKED"
                "CAMERA" -> if (updated.isRecording) "RECORDING" else "STOPPED"
                else -> if (updated.isOn) "POWERED ON" else "POWERED OFF"
            }
            repository.addHistoryLog(
                "Manual Control",
                "User manually changed status of ${device.name} in ${device.room} to $statusStr.",
                if (device.type == "LOCK") "LOCK" else "SYSTEM"
            )
        }
    }

    // Adjust specific device parameters
    fun adjustDevice(device: Device) {
        viewModelScope.launch {
            repository.updateDevice(device)
            if (_activeDeviceDetail.value?.id == device.id) {
                _activeDeviceDetail.value = device
            }
        }
    }

    // Execute Scenes
    fun activateScene(sceneId: String) {
        viewModelScope.launch {
            repository.triggerScene(sceneId)
        }
    }

    // Create custom automation rule
    fun createAutomationRule(name: String, triggerType: String, condition: String, targetId: String, action: String, actionVal: String) {
        viewModelScope.launch {
            val rule = AutomationRule(
                name = name,
                triggerType = triggerType,
                triggerCondition = condition,
                actionDeviceId = targetId,
                actionType = action,
                actionValue = actionVal
            )
            repository.addRule(rule)
            repository.addHistoryLog("Automation Added", "Custom automation rule '$name' created.", "SYSTEM")
        }
    }

    fun toggleRule(rule: AutomationRule) {
        viewModelScope.launch {
            repository.updateRule(rule.copy(isActive = !rule.isActive))
        }
    }

    fun deleteRule(ruleId: Int) {
        viewModelScope.launch {
            repository.deleteRule(ruleId)
        }
    }

    fun clearLogHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // Auth actions
    fun setAuthEmail(v: String) { _authEmail.value = v }
    fun setAuthPassword(v: String) { _authPassword.value = v }
    fun setAuthName(v: String) { _authName.value = v }
    fun setRegisterMode(v: Boolean) { _isRegisterMode.value = v }
    
    fun performLogin() {
        _authError.value = null
        if (_authEmail.value.isBlank() || _authPassword.value.isBlank()) {
            _authError.value = "Please fill in all credentials."
            return
        }
        // Simulated authorization
        _isLoggedIn.value = true
        viewModelScope.launch {
            repository.insertUser(User(email = _authEmail.value, name = _authName.value, distanceKm = 4.2))
            repository.addHistoryLog("Security Log", "User ${_authName.value} authenticated successfully.", "SECURITY")
        }
    }

    fun performRegister() {
        _authError.value = null
        if (_authEmail.value.isBlank() || _authPassword.value.isBlank() || _authName.value.isBlank()) {
            _authError.value = "All fields are required for registration."
            return
        }
        _isLoggedIn.value = true
        viewModelScope.launch {
            repository.insertUser(User(email = _authEmail.value, name = _authName.value, distanceKm = 4.2))
            repository.addHistoryLog("Security Log", "New user ${_authName.value} registered and authenticated.", "SECURITY")
        }
    }

    fun performLogout() {
        _isLoggedIn.value = false
        _authPassword.value = ""
        viewModelScope.launch {
            repository.addHistoryLog("Security Log", "User session terminated.", "SECURITY")
        }
    }

    // Simulate GPS geofencing distance
    fun toggleGpsSimulation() {
        viewModelScope.launch {
            val currUser = user.value
            if (currUser != null) {
                if (currUser.isAway) {
                    // Reset to Home
                    repository.updateUser(currUser.copy(isAway = false, distanceKm = 0.0))
                    repository.addHistoryLog("GPS Update", "User is back within home radius.", "SYSTEM")
                } else {
                    // Start simulated trip
                    repository.updateUser(currUser.copy(isAway = true, distanceKm = 5.0))
                    repository.addHistoryLog("GPS Update", "User departed. Armed geofence away protocols.", "SYSTEM")
                }
            }
        }
    }

    // Speech simulation commands
    fun openVoiceAssistant(open: Boolean) {
        _isVoiceAssistantOpen.value = open
        if (open) {
            _isVoiceListening.value = true
        } else {
            _isVoiceListening.value = false
        }
    }

    fun triggerSimulatedVoicePhrase(phrase: String) {
        _isVoiceListening.value = false
        _chatMessages.value = _chatMessages.value + ChatMessage(phrase, true)
        
        viewModelScope.launch {
            processChatWithAI(phrase)
        }
    }

    // AI Assistant Natural Language processor
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        _chatMessages.value = _chatMessages.value + ChatMessage(text, true)
        viewModelScope.launch {
            processChatWithAI(text)
        }
    }

    private suspend fun processChatWithAI(userText: String) {
        val lowercaseText = userText.lowercase()
        
        // Let the user know the AI is reading their command
        val loaderMsg = ChatMessage("Processing your home commands...", false)
        _chatMessages.value = _chatMessages.value + loaderMsg

        // 1. Check if Gemini API Key is loaded in secrets and call API
        val apiKey = BuildConfig.GEMINI_API_KEY
        var aiResult: String? = null

        if (apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                aiResult = callGeminiAPI(apiKey, userText)
            } catch (e: Exception) {
                // Fail-safe to fallback local rule engine
                aiResult = null
            }
        }

        // Remove the loader message
        _chatMessages.value = _chatMessages.value.filter { it != loaderMsg }

        // 2. Local fallback command parsing & direct hardware actions
        var commandExecuted = false
        val currentDevices = devices.value.toMutableList()

        if (lowercaseText.contains("bật đèn") || lowercaseText.contains("turn on light") || lowercaseText.contains("open light")) {
            val target = currentDevices.find { it.type == "LIGHT" }
            if (target != null && !target.isOn) {
                repository.updateDevice(target.copy(isOn = true, brightness = 100))
                repository.addHistoryLog("AI Action", "AI Assistant turned ON Ceiling Light.", "SYSTEM")
                commandExecuted = true
            }
        } else if (lowercaseText.contains("tắt đèn") || lowercaseText.contains("turn off light") || lowercaseText.contains("close light")) {
            val target = currentDevices.find { it.type == "LIGHT" }
            if (target != null && target.isOn) {
                repository.updateDevice(target.copy(isOn = false))
                repository.addHistoryLog("AI Action", "AI Assistant turned OFF Ceiling Light.", "SYSTEM")
                commandExecuted = true
            }
        } else if (lowercaseText.contains("bật điều hòa") || lowercaseText.contains("turn on ac") || lowercaseText.contains("turn on air")) {
            val target = currentDevices.find { it.id == "ac_living" }
            if (target != null && !target.isOn) {
                repository.updateDevice(target.copy(isOn = true, temperature = 24f))
                repository.addHistoryLog("AI Action", "AI Assistant turned ON AC.", "SYSTEM")
                commandExecuted = true
            }
        } else if (lowercaseText.contains("tắt điều hòa") || lowercaseText.contains("turn off ac") || lowercaseText.contains("turn off air")) {
            val target = currentDevices.find { it.id == "ac_living" }
            if (target != null && target.isOn) {
                repository.updateDevice(target.copy(isOn = false))
                repository.addHistoryLog("AI Action", "AI Assistant turned OFF AC.", "SYSTEM")
                commandExecuted = true
            }
        } else if (lowercaseText.contains("khóa cửa") || lowercaseText.contains("lock door") || lowercaseText.contains("secure door")) {
            val target = currentDevices.find { it.type == "LOCK" }
            if (target != null && !target.isLocked) {
                repository.updateDevice(target.copy(isLocked = true))
                repository.addHistoryLog("AI Action", "AI Assistant LOCKED Front Door.", "LOCK")
                commandExecuted = true
            }
        } else if (lowercaseText.contains("mở khóa") || lowercaseText.contains("unlock door") || lowercaseText.contains("open door")) {
            val target = currentDevices.find { it.type == "LOCK" }
            if (target != null && target.isLocked) {
                repository.updateDevice(target.copy(isLocked = false))
                repository.addHistoryLog("AI Action", "AI Assistant UNLOCKED Front Door.", "LOCK")
                commandExecuted = true
            }
        }

        // Formulate final response
        val finalResponseText = if (aiResult != null) {
            aiResult
        } else {
            if (commandExecuted) {
                "I have successfully processed your voice command and updated your smart home appliances in real-time."
            } else {
                "I analyzed your request. You can say 'Bật đèn', 'Tắt đèn', 'Bật điều hòa', 'Tắt điều hòa', 'Khóa cửa' or 'Mở khóa' to control your house."
            }
        }

        _chatMessages.value = _chatMessages.value + ChatMessage(finalResponseText, false)
    }

    // Direct REST implementation for Gemini API using OkHttp
    private suspend fun callGeminiAPI(apiKey: String, prompt: String): String = withContext(Dispatchers.IO) {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        val systemPrompt = "You are a friendly, intelligent Smart Home voice assistant named Robbie. The user can type/speak to you. Helpfully inform them you are executing their requests."
        
        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemPrompt)
                    })
                })
            })
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("Failed: ${response.code} ${response.message}")
            }
            val bodyString = response.body?.string() ?: throw Exception("Empty body")
            val responseJson = JSONObject(bodyString)
            val candidates = responseJson.getJSONArray("candidates")
            val content = candidates.getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")
            parts.getJSONObject(0).getString("text")
        }
    }
}
