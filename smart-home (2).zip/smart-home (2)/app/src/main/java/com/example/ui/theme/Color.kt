package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Glassmorphism and Glow Color Palette
val PrimaryGlow = Color(0xFF4DA6FF)   // Neon Blue glow
val SecondaryGlow = Color(0xFF7B61FF) // Vibrant Purple glow
val AccentGlow = Color(0xFF00FFD1)    // Electric Cyan
val DangerGlow = Color(0xFFFF5A5A)    // Alert Red
val WarningGlow = Color(0xFFFFB03A)   // Alert Amber

// Background Deep Dark Gradients
val SpaceDarkBg = Color(0xFF0F1115)   // Deep black space
val BlueDarkBg = Color(0xFF161B24)    // Bluish dark space
val GlassCardBg = Color(0x1AFFFFFF)   // Frosted white overlay (rgba 255,255,255,0.1)
val GlassCardBorder = Color(0x26FFFFFF) // Delicate white glass border (rgba 255,255,255,0.15)
val GlassCardGlowBorder = Color(0x4D4DA6FF) // Glowing active glass border

// Basic Slate colors
val SlateTextLight = Color(0xFFE2E8F0)
val SlateTextMuted = Color(0xFF94A3B8)
val DarkNavyText = Color(0xFF0F172A)
