package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.model.Device
import com.example.data.model.AutomationRule
import com.example.data.model.Scene
import com.example.data.model.HistoryLog
import com.example.data.model.User
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class SmartHomeRepository(private val context: Context) {

    private val db: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "smarthome_db"
    )
    .fallbackToDestructiveMigration()
    .build()

    private val deviceDao = db.deviceDao()
    private val automationDao = db.automationDao()
    private val sceneDao = db.sceneDao()
    private val historyDao = db.historyDao()
    private val userDao = db.userDao()

    // Exposed Flows for Reactive UI
    val devicesFlow: Flow<List<Device>> = deviceDao.getAllDevicesFlow()
    val rulesFlow: Flow<List<AutomationRule>> = automationDao.getAllRulesFlow()
    val scenesFlow: Flow<List<Scene>> = sceneDao.getAllScenesFlow()
    val historyFlow: Flow<List<HistoryLog>> = historyDao.getRecentHistoryLogsFlow()
    val userFlow: Flow<User?> = userDao.getUserFlow()

    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        repositoryScope.launch {
            initializeDefaults()
            startSimulationEngine()
        }
    }

    private suspend fun initializeDefaults() {
        // Initialize default devices if none exist
        val existingDevices = deviceDao.getAllDevices()
        if (existingDevices.isEmpty()) {
            val defaultDevices = listOf(
                Device(
                    id = "light_living",
                    name = "Ceiling Light",
                    room = "Living Room",
                    type = "LIGHT",
                    isOn = true,
                    brightness = 80,
                    rgbColor = "#4DA6FF"
                ),
                Device(
                    id = "ac_living",
                    name = "Living Room AC",
                    room = "Living Room",
                    type = "AC",
                    isOn = false,
                    temperature = 24.0f,
                    acMode = "COOL",
                    fanSpeed = "AUTO"
                ),
                Device(
                    id = "fan_bedroom",
                    name = "Smart Fan",
                    room = "Bedroom",
                    type = "FAN",
                    isOn = false,
                    brightness = 50, // repurposed for speed percentage
                    fanSpeed = "MED"
                ),
                Device(
                    id = "lock_front",
                    name = "Front Door Lock",
                    room = "Front Door",
                    type = "LOCK",
                    isLocked = true
                ),
                Device(
                    id = "cam_front",
                    name = "Front Camera",
                    room = "Front Door",
                    type = "CAMERA",
                    isRecording = true
                ),
                Device(
                    id = "plug_living",
                    name = "Media Center Plug",
                    room = "Living Room",
                    type = "PLUG",
                    isOn = true
                )
            )
            deviceDao.insertAllDevices(defaultDevices)

            // Insert default Scenes
            val defaultScenes = listOf(
                Scene("good_night", "Good Night", "Turns off lights, locks doors, and arms security camera.", "bedtime"),
                Scene("welcome_home", "Welcome Home", "Disarms lock, turns on ceiling lights and AC.", "home"),
                Scene("movie_time", "Movie Time", "Dims lights to 20%, turns on media plug, cool AC mode.", "movie"),
                Scene("away_mode", "Away Mode", "Turns off all devices, locks doors, starts video recording.", "door_back")
            )
            sceneDao.insertAllScenes(defaultScenes)

            // Insert default Automation Rules
            val defaultRules = listOf(
                AutomationRule(
                    name = "Evening Automatic Lights",
                    triggerType = "TIME",
                    triggerCondition = "18:00",
                    actionDeviceId = "light_living",
                    actionType = "TURN_ON",
                    actionValue = ""
                ),
                AutomationRule(
                    name = "Cool Down Room (Hot Temperature)",
                    triggerType = "TEMP",
                    triggerCondition = "30.0", // Trigger if room temp >= 30.0
                    actionDeviceId = "ac_living",
                    actionType = "TURN_ON",
                    actionValue = "24.0"
                ),
                AutomationRule(
                    name = "Motion Activated Lights",
                    triggerType = "MOTION",
                    triggerCondition = "MOTION_DETECTED",
                    actionDeviceId = "light_living",
                    actionType = "TURN_ON",
                    actionValue = ""
                ),
                AutomationRule(
                    name = "Arrive Home AC Autostart",
                    triggerType = "LOCATION",
                    triggerCondition = "GPS_NEAR",
                    actionDeviceId = "ac_living",
                    actionType = "TURN_ON",
                    actionValue = "22.0"
                )
            )
            for (rule in defaultRules) {
                automationDao.insertRule(rule)
            }

            // Insert default user
            userDao.insertUser(User(email = "laxin.27112000@gmail.com", name = "Robbie", distanceKm = 4.2))

            // Add first historic log
            historyDao.insertLog(HistoryLog(title = "System Setup", message = "Smart Home System initialized successfully.", type = "SYSTEM"))
        }
    }

    // Database Actions
    suspend fun updateDevice(device: Device) {
        deviceDao.updateDevice(device)
    }

    suspend fun addRule(rule: AutomationRule) {
        automationDao.insertRule(rule)
    }

    suspend fun updateRule(rule: AutomationRule) {
        automationDao.updateRule(rule)
    }

    suspend fun deleteRule(id: Int) {
        automationDao.deleteRuleById(id)
    }

    suspend fun addHistoryLog(title: String, message: String, type: String) {
        historyDao.insertLog(HistoryLog(title = title, message = message, type = type))
    }

    suspend fun clearHistory() {
        historyDao.clearHistory()
    }

    suspend fun updateUser(user: User) {
        userDao.updateUser(user)
    }

    suspend fun insertUser(user: User) {
        userDao.insertUser(user)
    }

    // Scene Trigger Execution
    suspend fun triggerScene(sceneId: String) {
        val devices = deviceDao.getAllDevices().toMutableList()

        when (sceneId) {
            "good_night" -> {
                // Lights off, locks door, camera recording, ac on 26
                devices.forEachIndexed { idx, dev ->
                    if (dev.type == "LIGHT") {
                        devices[idx] = dev.copy(isOn = false)
                    } else if (dev.type == "LOCK") {
                        devices[idx] = dev.copy(isLocked = true)
                    } else if (dev.type == "CAMERA") {
                        devices[idx] = dev.copy(isRecording = true)
                    } else if (dev.id == "ac_living") {
                        devices[idx] = dev.copy(isOn = true, temperature = 26.0f)
                    }
                }
                addHistoryLog("Scene Activated", "Scene 'Good Night' activated. Front door secured.", "SYSTEM")
            }
            "welcome_home" -> {
                // Lights on, door unlock, AC on 22
                devices.forEachIndexed { idx, dev ->
                    if (dev.id == "light_living") {
                        devices[idx] = dev.copy(isOn = true, brightness = 90)
                    } else if (dev.type == "LOCK") {
                        devices[idx] = dev.copy(isLocked = false)
                    } else if (dev.id == "ac_living") {
                        devices[idx] = dev.copy(isOn = true, temperature = 22.0f)
                    }
                }
                addHistoryLog("Scene Activated", "Welcome Home! Living Room devices initialized.", "SYSTEM")
            }
            "movie_time" -> {
                // Lights dim (20%), Media plug ON, AC cool (23)
                devices.forEachIndexed { idx, dev ->
                    if (dev.id == "light_living") {
                        devices[idx] = dev.copy(isOn = true, brightness = 20, rgbColor = "#7B61FF")
                    } else if (dev.id == "plug_living") {
                        devices[idx] = dev.copy(isOn = true)
                    } else if (dev.id == "ac_living") {
                        devices[idx] = dev.copy(isOn = true, temperature = 23.0f, acMode = "COOL")
                    }
                }
                addHistoryLog("Scene Activated", "Scene 'Movie Time' activated. Cozy mode armed.", "SYSTEM")
            }
            "away_mode" -> {
                // Everything off, locks door, cam active
                devices.forEachIndexed { idx, dev ->
                    if (dev.type == "LIGHT") {
                        devices[idx] = dev.copy(isOn = false)
                    } else if (dev.type == "AC" || dev.type == "FAN" || dev.type == "PLUG") {
                        devices[idx] = dev.copy(isOn = false)
                    } else if (dev.type == "LOCK") {
                        devices[idx] = dev.copy(isLocked = true)
                    } else if (dev.type == "CAMERA") {
                        devices[idx] = dev.copy(isRecording = true)
                    }
                }
                addHistoryLog("Scene Activated", "Scene 'Away Mode' activated. All appliances off, camera armed.", "SYSTEM")
            }
        }

        deviceDao.insertAllDevices(devices)
    }

    // continuous Simulation Engine
    private fun startSimulationEngine() {
        repositoryScope.launch {
            while (isActive) {
                delay(2000) // update tick every 2 seconds

                // 1. Fetch current devices & active rules
                val devices = deviceDao.getAllDevices().toMutableList()
                val activeRules = automationDao.getActiveRules()
                val user = userDao.getUserFlow().firstOrNull()

                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                val currentLocalTime = timeFormat.format(Date())

                var stateChanged = false

                // 2. Simulate Motion Sensor random trigger (every ~20 seconds 15% probability)
                if (Random.nextFloat() < 0.12f) {
                    val camIdx = devices.indexOfFirst { it.type == "CAMERA" }
                    if (camIdx != -1) {
                        val camera = devices[camIdx]
                        if (!camera.motionDetected) {
                            devices[camIdx] = camera.copy(motionDetected = true)
                            stateChanged = true

                            addHistoryLog("Motion Alert", "Motion detected at the Front Door!", "SECURITY")

                            // Evaluate MOTION rules
                            activeRules.forEach { rule ->
                                if (rule.triggerType == "MOTION" && rule.triggerCondition == "MOTION_DETECTED") {
                                    triggerRuleAction(rule, devices)
                                }
                            }
                        }
                    }
                } else {
                    // Turn off motion sensor state after 6 seconds to return to normal
                    val camIdx = devices.indexOfFirst { it.type == "CAMERA" && it.motionDetected }
                    if (camIdx != -1) {
                        devices[camIdx] = devices[camIdx].copy(motionDetected = false)
                        stateChanged = true
                    }
                }

                // 3. Simulate Power consumption changes
                devices.forEachIndexed { idx, dev ->
                    var drawW = 0.0f
                    if (dev.isOn) {
                        drawW = when (dev.type) {
                            "LIGHT" -> 8.0f * (dev.brightness / 100.0f)
                            "AC" -> if (dev.acMode == "COOL") 1200.0f else 1500.0f
                            "FAN" -> if (dev.fanSpeed == "HIGH") 60.0f else if (dev.fanSpeed == "MED") 45.0f else 25.0f
                            "PLUG" -> 110.0f + Random.nextFloat() * 15f // simulated media load
                            else -> 0.0f
                        }
                    }
                    if (dev.type == "CAMERA" && dev.isRecording) {
                        drawW += 5.0f // continuous small camera draw
                    }

                    // Dynamically accumulate total energy kWh
                    val hoursPassed = 2.0 / 3600.0 // 2 seconds tick
                    val addedKwh = (drawW / 1000.0f) * hoursPassed.toFloat()

                    if (drawW != dev.powerUsageW || addedKwh > 0.0f) {
                        devices[idx] = dev.copy(
                            powerUsageW = drawW,
                            totalUsageKwh = dev.totalUsageKwh + addedKwh
                        )
                        stateChanged = true
                    }
                }

                // 4. Evaluate time-based rules
                activeRules.forEach { rule ->
                    if (rule.triggerType == "TIME" && rule.triggerCondition == currentLocalTime) {
                        // Ensure action actually changes state to avoid looping logs
                        triggerRuleAction(rule, devices)
                    }
                }

                // 5. Simulate GPS proximity logic
                if (user != null && user.isAway) {
                    val nextDistance = (user.distanceKm - 0.2).coerceAtLeast(0.0)
                    userDao.insertUser(user.copy(distanceKm = nextDistance, isAway = nextDistance > 0.0))

                    if (nextDistance == 0.0 && user.distanceKm > 0.0) {
                        // Just arrived home
                        addHistoryLog("Location Trigger", "GPS detected user arrived within home boundary.", "SYSTEM")
                        activeRules.forEach { rule ->
                            if (rule.triggerType == "LOCATION" && rule.triggerCondition == "GPS_NEAR") {
                                triggerRuleAction(rule, devices)
                            }
                        }
                    }
                }

                if (stateChanged) {
                    deviceDao.insertAllDevices(devices)
                }
            }
        }
    }

    private suspend fun triggerRuleAction(rule: AutomationRule, devices: MutableList<Device>) {
        val targetIdx = devices.indexOfFirst { it.id == rule.actionDeviceId }
        if (targetIdx != -1) {
            val dev = devices[targetIdx]
            var altered = false
            var actionStr = ""

            when (rule.actionType) {
                "TURN_ON" -> {
                    if (!dev.isOn) {
                        devices[targetIdx] = dev.copy(isOn = true)
                        altered = true
                        actionStr = "TURNED ON"
                    }
                }
                "TURN_OFF" -> {
                    if (dev.isOn) {
                        devices[targetIdx] = dev.copy(isOn = false)
                        altered = true
                        actionStr = "TURNED OFF"
                    }
                }
                "LOCK" -> {
                    if (!dev.isLocked) {
                        devices[targetIdx] = dev.copy(isLocked = true)
                        altered = true
                        actionStr = "LOCKED"
                    }
                }
                "UNLOCK" -> {
                    if (dev.isLocked) {
                        devices[targetIdx] = dev.copy(isLocked = false)
                        altered = true
                        actionStr = "UNLOCKED"
                    }
                }
                "SET_TEMP" -> {
                    val parsedTemp = rule.actionValue.toFloatOrNull() ?: 24.0f
                    if (dev.temperature != parsedTemp || !dev.isOn) {
                        devices[targetIdx] = dev.copy(isOn = true, temperature = parsedTemp)
                        altered = true
                        actionStr = "set Temperature to ${parsedTemp}°C"
                    }
                }
                "SET_BRIGHTNESS" -> {
                    val parsedBright = rule.actionValue.toIntOrNull() ?: 80
                    if (dev.brightness != parsedBright || !dev.isOn) {
                        devices[targetIdx] = dev.copy(isOn = true, brightness = parsedBright)
                        altered = true
                        actionStr = "set Brightness to ${parsedBright}%"
                    }
                }
            }

            if (altered) {
                addHistoryLog(
                    "Rule Triggered",
                    "Automation Rule '${rule.name}' automatically $actionStr for device '${dev.name}'",
                    "SYSTEM"
                )
            }
        }
    }
}
