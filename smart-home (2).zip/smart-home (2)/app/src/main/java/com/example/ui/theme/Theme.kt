package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val AppCornerLarge: Dp = 24.dp
val AppCornerMedium: Dp = 16.dp
val AppCornerSmall: Dp = 12.dp
val AppCornerTiny: Dp = 8.dp
val AppCornerButton: Dp = 20.dp
val AppCornerPill: Dp = 100.dp
val AppCornerNav: Dp = 28.dp

val AppElevationSurface: Dp = 16.dp
val AppElevationActiveSurface: Dp = 24.dp
val AppElevationSoft: Dp = 12.dp

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryGlow,
    secondary = SecondaryGlow,
    tertiary = AccentGlow,
    background = SpaceDarkBg,
    surface = BlueDarkBg,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = SlateTextLight,
    onSurface = SlateTextLight,
    error = DangerGlow
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark Theme for Premium Look
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
