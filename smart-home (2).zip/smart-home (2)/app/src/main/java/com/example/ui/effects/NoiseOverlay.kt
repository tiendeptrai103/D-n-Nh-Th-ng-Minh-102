package com.example.ui.effects

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.random.Random

@Composable
fun NoiseOverlay(modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawNoiseLayer(this)
        }
    }
}

private fun drawNoiseLayer(drawScope: DrawScope) {
    val width = drawScope.size.width
    val height = drawScope.size.height
    val density = 0.0025f
    val alpha = 0.03f

    repeat((width * height * density).toInt()) {
        val x = Random.nextFloat() * width
        val y = Random.nextFloat() * height
        drawScope.drawRect(
            color = Color.White.copy(alpha = alpha * Random.nextFloat()),
            topLeft = androidx.compose.ui.geometry.Offset(x, y),
            size = androidx.compose.ui.geometry.Size(1f, 1f)
        )
    }
}
