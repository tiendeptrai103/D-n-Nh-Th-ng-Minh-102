package com.example.ui.effects

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer

@Composable
fun BlurLayer(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    alpha: Float = 0.04f
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                shadowElevation = 0f
            }
            .background(color.copy(alpha = alpha))
    )
}
